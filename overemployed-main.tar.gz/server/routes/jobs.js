import { Router } from 'express';
import {
  getAllApplications,
  getApplication,
  queryByStatus,
  updateApplicationStatus,
  deleteApplication,
  getMetrics,
} from '../services/dynamodb.js';

const ALLOWED_JOB_STATUSES = new Set([
  'found',
  'cv_generated',
  'reviewed',
  'ready',
  'applying',
  'blocked',
  'applied',
  'failed',
  'rejected',
]);
import { getApplyProofBuffer, getApplyProofMeta } from '../services/applyProof.js';
import { getMemoryKey } from '../services/memory.js';
import { getDocxPath, generateDocx } from '../services/docxFormatter.js';
import { getPdfPath, generatePdf } from '../services/cvPdf.js';
import { getApplyLiveFrameBuffer } from '../services/applyLiveFrame.js';

const router = Router();

router.get('/api/jobs', async (req, res, next) => {
  try {
    const jobs = await getAllApplications();
    res.json(jobs);
  } catch (err) {
    next(err);
  }
});

router.get('/api/metrics', async (req, res, next) => {
  try {
    const raw = await getMetrics();
    const runHistory = (await getMemoryKey('agents.orchestrator.runHistory')) || [];
    const lastRun = runHistory.length > 0 ? runHistory[runHistory.length - 1] : null;

    const jobsFoundFromRuns = runHistory.reduce((sum, r) => sum + (r.jobsFound || 0), 0);

    res.json({
      total: raw.total,
      byStatus: raw.byStatus,
      totalRuns: runHistory.length,
      jobsFound: jobsFoundFromRuns || raw.total,
      cvsReady:
        (raw.byStatus.ready || 0) +
        (raw.byStatus.reviewed || 0) +
        (raw.byStatus.cv_generated || 0) +
        (raw.byStatus.applied || 0),
      applicationsTracked: raw.total,
      lastRun: lastRun?.timestamp || null,
    });
  } catch (err) {
    next(err);
  }
});

router.get('/api/jobs/status/:status', async (req, res, next) => {
  try {
    const jobs = await queryByStatus(req.params.status);
    res.json(jobs);
  } catch (err) {
    next(err);
  }
});

/** Verification screenshots for successful automation apply */
router.get('/api/jobs/:id/apply-proof/meta', async (req, res, next) => {
  try {
    const job = await getApplication(req.params.id);
    if (!job) return res.status(404).json({ error: 'Application not found' });
    let meta = job.applyProof || null;
    if (!meta?.shots?.length) {
      meta = await getApplyProofMeta(req.params.id);
    }
    if (!meta?.shots?.length) {
      return res.json({ applicationId: req.params.id, capturedAt: null, shots: [], engine: null });
    }
    res.json(meta);
  } catch (err) {
    next(err);
  }
});

router.get('/api/jobs/:id/apply-proof/:index', async (req, res, next) => {
  try {
    const job = await getApplication(req.params.id);
    if (!job) return res.status(404).json({ error: 'Application not found' });

    const buf = await getApplyProofBuffer(req.params.id, req.params.index);
    if (!buf) {
      return res.status(404).json({ error: 'Screenshot not found' });
    }
    res.set('Content-Type', 'image/png');
    res.set('Cache-Control', 'private, max-age=3600');
    res.send(buf);
  } catch (err) {
    next(err);
  }
});

/** Latest Nova / automation viewport frame while status is applying (throttled on server). */
router.get('/api/jobs/:id/live-frame', async (req, res, next) => {
  try {
    const buf = getApplyLiveFrameBuffer(req.params.id);
    if (!buf) return res.status(204).end();
    res.set('Content-Type', 'image/png');
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
    res.send(buf);
  } catch (err) {
    next(err);
  }
});

router.get('/api/jobs/:id', async (req, res, next) => {
  try {
    const job = await getApplication(req.params.id);
    if (!job) {
      return res.status(404).json({ error: 'Application not found' });
    }
    res.json(job);
  } catch (err) {
    next(err);
  }
});

router.get('/api/jobs/:id/cv', async (req, res, next) => {
  try {
    const { id } = req.params;
    let filePath = await getDocxPath(id);

    if (!filePath) {
      const job = await getApplication(id);
      if (!job) return res.status(404).json({ error: 'Application not found' });
      if (!job.tailoredCV) return res.status(404).json({ error: 'No CV generated for this application' });
      filePath = await generateDocx(job.tailoredCV, id);
    }

    const safeTitle = (await getApplication(id))?.roleTitle?.replace(/[^a-zA-Z0-9 -]/g, '') || id;
    res.download(filePath, `CV - ${safeTitle}.docx`);
  } catch (err) {
    next(err);
  }
});

router.get('/api/jobs/:id/cv/pdf', async (req, res, next) => {
  try {
    const { id } = req.params;
    let filePath = await getPdfPath(id);

    if (!filePath) {
      const job = await getApplication(id);
      if (!job) return res.status(404).json({ error: 'Application not found' });
      if (!job.tailoredCV) return res.status(404).json({ error: 'No CV generated for this application' });
      filePath = await generatePdf(job.tailoredCV, id);
    }

    const safeTitle = (await getApplication(id))?.roleTitle?.replace(/[^a-zA-Z0-9 -]/g, '') || id;
    res.download(filePath, `CV - ${safeTitle}.pdf`);
  } catch (err) {
    next(err);
  }
});

router.patch('/api/jobs/:id/status', async (req, res, next) => {
  try {
    const { status } = req.body;
    if (!status) {
      return res.status(400).json({ error: 'status is required' });
    }
    if (!ALLOWED_JOB_STATUSES.has(status)) {
      return res.status(400).json({ error: 'Invalid status', allowed: [...ALLOWED_JOB_STATUSES] });
    }
    const existing = await getApplication(req.params.id);
    if (!existing) {
      return res.status(404).json({ error: 'Application not found' });
    }
    const updated = await updateApplicationStatus(req.params.id, status);
    res.json(updated);
  } catch (err) {
    next(err);
  }
});

router.delete('/api/jobs/:id', async (req, res, next) => {
  try {
    await deleteApplication(req.params.id);
    res.json({ deleted: true });
  } catch (err) {
    next(err);
  }
});

export default router;
